package com.example.spacemissionanalyzersystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpacemissionanalyzersystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
