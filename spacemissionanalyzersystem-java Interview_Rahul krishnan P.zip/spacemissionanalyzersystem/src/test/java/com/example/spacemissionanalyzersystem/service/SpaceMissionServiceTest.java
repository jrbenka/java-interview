package com.example.spacemissionanalyzersystem.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.spacemissionanalyzersystem.model.SpaceMissionStatistics;
import com.example.spacemissionanalyzersystem.repository.SpaceMissionRepo;

public class SpaceMissionServiceTest {
	
	@Mock
	SpaceMissionRepo spaceMissionRepo;
	
	@InjectMocks
	SpaceMissionImpl spaceMissionImpl;
	
	@Test
	void getMissionStatisticsTest() {
		
		SpaceMissionStatistics spaceMissionStatistics = new SpaceMissionStatistics(43,33.4,32.5);
		
		when(spaceMissionRepo.getStatistics()).thenReturn(spaceMissionStatistics);
		
		ResponseEntity<SpaceMissionStatistics> response = spaceMissionImpl.getMissionStatistics();
		
		assertEquals(response.getBody(),spaceMissionStatistics);
		
		assertEquals(response.getStatusCode(),HttpStatus.OK);
		
		verify(spaceMissionRepo).getStatistics();
	}
	
//	@Test
//	void logMissionTest() {
//		
//		SpaceMission spacemission = new SpaceMissionStatistics(43,33.4,32.5);
//		
//		when(spaceMissionRepo.save(spacemission)).thenReturn(spaceMissionStatistics);
//		
//		ResponseEntity<SpaceMissionStatistics> response = spaceMissionImpl.getMissionStatistics();
//		
//		assertEquals(response.getBody(),spaceMissionStatistics);
//		
//		assertEquals(response.getStatusCode(),HttpStatus.OK);
//		
//		verify(spaceMissionRepo).getStatistics();
//	}


}
