package com.java.problem.solving.task;

public class Solution {
	/**
	 * Finds the length of the longest alternating subsequence in the given array.
	 * 
	 * @param nums An array of integers
	 * @return The length of the longest alternating subsequence
	 */
	public int longestAlternatingSubsequence(int[] nums) {
		int count = 0;
		int finalCount = 0;
		for (int i = 0; i < nums.length-3 ; i++) {
			if (nums[i] < nums[i + 1]) {
				count++;
				finalCount = comparisonGreater(nums, i+1, i + 2, count);
			} else if (nums[i] > nums[i + 1]) {
				count++;
				finalCount = comparisonSmaller(nums, i+1, i + 2, count);
			}
		}

		return finalCount;
	}

	public int comparisonGreater(int[] nums, int primaryNumber, int secondarynumber, int count) {
		if (nums[primaryNumber] > nums[secondarynumber]) {
			count++;

			return comparisonSmaller(nums, secondarynumber, secondarynumber + 1, count);
		}
		return count;
	}

	private int comparisonSmaller(int[] nums, int primaryNumber, int secondarynumber, int count) {

		if (nums[primaryNumber] < nums[secondarynumber]) {
			count++;
			return comparisonGreater(nums, secondarynumber, secondarynumber + 1, count);
		}
		return count;
	}

	// You can add helper methods if needed
}