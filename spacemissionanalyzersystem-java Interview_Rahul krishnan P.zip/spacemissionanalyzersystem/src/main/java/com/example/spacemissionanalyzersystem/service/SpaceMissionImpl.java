package com.example.spacemissionanalyzersystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.spacemissionanalyzersystem.model.SpaceMission;
import com.example.spacemissionanalyzersystem.model.SpaceMissionStatistics;
import com.example.spacemissionanalyzersystem.repository.SpaceMissionRepo;

@Service
public class SpaceMissionImpl implements SpaceMissionService {

	@Autowired
	SpaceMissionRepo spaceMissionRepo;

	@Override
	public ResponseEntity<SpaceMissionStatistics> getMissionStatistics() {

		try {
			return new ResponseEntity<>(spaceMissionRepo.getStatistics(), HttpStatus.OK);

		} catch (Exception e) {

			return new ResponseEntity<>(new SpaceMissionStatistics(), HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public ResponseEntity<SpaceMission> logMission(SpaceMission spacemission) {

		try {

			spaceMissionRepo.save(spacemission);

			return new ResponseEntity<>(spacemission, HttpStatus.CREATED);

		} catch (Exception e) {

			return new ResponseEntity<>(new SpaceMission(), HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public ResponseEntity<SpaceMission> getLatestMission(String date) {
		try {
			return new ResponseEntity<>(spaceMissionRepo.findBylaunchDate(date), HttpStatus.OK);
		} catch (Exception e) {

			return new ResponseEntity<>(new SpaceMission(), HttpStatus.OK);
		}
	}

}
