package com.example.spacemissionanalyzersystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.spacemissionanalyzersystem.model.SpaceMission;
import com.example.spacemissionanalyzersystem.model.SpaceMissionStatistics;
import com.example.spacemissionanalyzersystem.service.SpaceMissionService;

@RestController
@RequestMapping("api")
public class SpaceMissionController {
	
	@Autowired
	SpaceMissionService spaceMissionService;
	
	@PostMapping("/missions")
	public ResponseEntity<SpaceMission> logMission(@RequestBody SpaceMission  spacemission){
		
		return spaceMissionService.logMission(spacemission);
	}
	

	@GetMapping("/missions/stats")
	public ResponseEntity<SpaceMissionStatistics> getMissionStatistics() {

		return spaceMissionService.getMissionStatistics();

	}
	
	@GetMapping("/missions/latest/{date}")
	public ResponseEntity<SpaceMission> getLatestMission(@PathVariable String date){
		
		return spaceMissionService.getLatestMission(date);
		
	}

}
