package com.example.spacemissionanalyzersystem.model;

public class EnumClass {

	public enum MissionType {

		SATELLITE_DEPLOYMENT, EXPLORATION, RESUPPLY
	}

	public enum StatusType {

		SUCCESS, FAILURE, IN_PROGRESS
	}

}
