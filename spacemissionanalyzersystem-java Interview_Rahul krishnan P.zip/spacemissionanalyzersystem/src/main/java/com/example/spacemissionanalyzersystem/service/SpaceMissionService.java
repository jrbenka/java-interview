package com.example.spacemissionanalyzersystem.service;

import org.springframework.http.ResponseEntity;

import com.example.spacemissionanalyzersystem.model.SpaceMission;
import com.example.spacemissionanalyzersystem.model.SpaceMissionStatistics;

public interface SpaceMissionService {
	
	ResponseEntity<SpaceMissionStatistics> getMissionStatistics();

	ResponseEntity<SpaceMission> logMission(SpaceMission spacemission);

	ResponseEntity<SpaceMission> getLatestMission(String date);

}
