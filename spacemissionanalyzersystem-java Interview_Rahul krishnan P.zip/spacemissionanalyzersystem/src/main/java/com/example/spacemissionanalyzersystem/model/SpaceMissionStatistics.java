package com.example.spacemissionanalyzersystem.model;

public class SpaceMissionStatistics {

	private Integer totalMissions;

	private Double Succesrate;

	private Double averageCrewSize;

	public SpaceMissionStatistics(Integer totalMissions, Double succesrate, Double averageCrewSize) {
		super();
		this.totalMissions = totalMissions;
		Succesrate = succesrate;
		this.averageCrewSize = averageCrewSize;
	}

	public SpaceMissionStatistics() {
	}

	public Integer getTotalMissions() {
		return totalMissions;
	}

	public void setTotalMissions(Integer totalMissions) {
		this.totalMissions = totalMissions;
	}

	public Double getSuccesrate() {
		return Succesrate;
	}

	public void setSuccesrate(Double succesrate) {
		Succesrate = succesrate;
	}

	public Double getAverageCrewSize() {
		return averageCrewSize;
	}

	public void setAverageCrewSize(Double averageCrewSize) {
		this.averageCrewSize = averageCrewSize;
	}

}
