package com.example.spacemissionanalyzersystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.example.spacemissionanalyzersystem.model.SpaceMission;
import com.example.spacemissionanalyzersystem.model.SpaceMissionStatistics;

@Repository
public interface SpaceMissionRepo extends JpaRepository<SpaceMission, Integer> {
	
// 	@Query("Select
	SpaceMissionStatistics getStatistics();

	SpaceMission findBylaunchDate(String date);
	

}
