package com.example.spacemissionanalyzersystem.model;

public class ResponseCode {

}
