package com.example.spacemissionanalyzersystem.model;

import com.example.spacemissionanalyzersystem.model.EnumClass.MissionType;
import com.example.spacemissionanalyzersystem.model.EnumClass.StatusType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class SpaceMission {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String missionName;
	
	private String launchDate;
	
	private Integer crewSize;
	
	private MissionType missionType;
	
	private StatusType status;
	
	public SpaceMission(Integer id, String missionName, String launchDate, Integer crewSize, MissionType missionType,
			StatusType status) {
		super();
		this.id = id;
		this.missionName = missionName;
		this.launchDate = launchDate;
		this.crewSize = crewSize;
		this.missionType = missionType;
		this.status = status;
	}

	public SpaceMission() {
	}

	public MissionType getMissionType() {
		return missionType;
	}

	public void setMissionType(MissionType missionType) {
		this.missionType = missionType;
	}

	public StatusType getStatusType() {
		return status;
	}

	public void setStatusType(StatusType statusType) {
		this.status = statusType;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMissionName() {
		return missionName;
	}

	public void setMissionName(String missionName) {
		this.missionName = missionName;
	}

	public String getLaunchDate() {
		return launchDate;
	}

	public void setLaunchDate(String launchDate) {
		this.launchDate = launchDate;
	}

	public Integer getCrewSize() {
		return crewSize;
	}

	public void setCrewSize(Integer crewSize) {
		this.crewSize = crewSize;
	}

}
