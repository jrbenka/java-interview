package com.example.spacemissionanalyzersystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpacemissionanalyzersystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpacemissionanalyzersystemApplication.class, args);
	}

}
